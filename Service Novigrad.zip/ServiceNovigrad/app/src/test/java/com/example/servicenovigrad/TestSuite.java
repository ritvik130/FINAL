import org.junit.runner.RunWith;
import org.juit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
    Test1.class,
    Test2.class
})

public class TestSuite {
    
}
